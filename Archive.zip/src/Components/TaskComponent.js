import React, { useState, useContext } from "react";
import { Card, Button, Container, Modal, Form, FloatingLabel, Col, Row, ListGroup, ModalBody } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { faMagnifyingGlass, faUserPlus } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import TaskContext from "../Context/TaskContext";

export default function TaskComponent({task}) {
  
  let taskData = useContext(TaskContext);


  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const { viewIcon } = <FontAwesomeIcon icon={faMagnifyingGlass} />;

  return (
    <>

        <Card style={{ width: "100%" }} className="mt-2 mb-2">
          <Card.Body>
            <Card.Title>
              {task.title}</Card.Title>
            <Card.Text>
              <p>Task Description</p>
              <p>Due Date:</p>
              <p>Assignee: </p>
            </Card.Text>
            <Row>
              <Col className="">
                <Form.Group>
                  <Form.Select
                      aria-label="Default select example"
                      className=""
                      // value={blogCategory}
                      // onChange={({ target: { value } }) => setBlogCategory(value)}
                    >
                      <option>Status</option>
                      <option value="ToDo">To-Do</option>
                      <option value="InProgress">In Progress</option>
                      <option value="Done">Done</option>
                    </Form.Select>
                </Form.Group>
              </Col>
              <Col>
              <Button variant="info">Update Status</Button>
              </Col>
            </Row>
            <Row className="mt-2">
              <Col>
                <Button variant="success" onClick={handleShow}>
                  View/Edit Task
                </Button>
              </Col>
            </Row>
          </Card.Body>
        </Card>


      <Modal size="lg" show={show} onHide={handleClose}>
        {/* check if user is specialist */}
        {/* return ( {user.isSpecialist ?  (
          <Modal.Header closeButton>
          <Modal.Title>View Task</Modal.Title>
        </Modal.Header>
        <Modal.Body>

        </Modal.Body>
        ): }) */}
        <Modal.Header closeButton>
          <Modal.Title>Edit Task</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="formGroupEmail">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="title"
                placeholder="Enter title"
                // value={blogTitle}
                // onChange={(e) => setBlogTitle(e.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formGroupPassword">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                type="description"
                placeholder="Description"
                // value={blogDescription}
                // onChange={(e) => setBlogDescription(e.target.value)}
              />
            </Form.Group>
            <Form.Group>
              <Row>
                <Col>
                  <Row>
                    <Col>
                  <Form.Label className="mt-3">Due Date: </Form.Label>
                    </Col>
                    <Col>
                  <input className="mt-3" type="date"></input>
                    </Col>
                  </Row>
                </Col>
                <Col>
              <Form.Select
                    aria-label="Default select example"
                    className="mt-2"
                    // value={blogCategory}
                    // onChange={({ target: { value } }) => setBlogCategory(value)}
                  >
                    <option>Pick a Priority</option>
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </Form.Select>
                </Col>
              </Row>
            </Form.Group>
            <Form.Group className="mb-3 mt-3" controlId="formGroupPassword">
              <Form.Label>Roles Assigned</Form.Label>
              {/* have this option only available for admin, subadmin, and PM? */}
              <Row>
                <Col>
                  <FloatingLabel controlId="floatingRole" label="Name">
                    <Form.Control type="password" placeholder="Assignee" />
                  </FloatingLabel>
                </Col>
                <Col>
                  <Form.Select
                    aria-label="Default select example"
                    className="mt-2"
                    // value={blogCategory}
                    // onChange={({ target: { value } }) => setBlogCategory(value)}
                  >
                    <option>Pick a Role</option>
                    <option value="Admin">Admin</option>
                    <option value="Subadmin">Subadmin</option>
                    <option value="PM">Project Manager</option>
                    <option value="Specialist">Specialist</option>
                  </Form.Select>
                </Col>
                <Col xs={2} className="mt-2">
                  <Button>Add</Button>
                </Col>
              </Row>
            </Form.Group>
          </Form>
          <Row>
            {/* map thru roles and add to list group, if none then null? */}
          <ListGroup variant="flush">
            <ListGroup.Item>Admin: Cras justo odio</ListGroup.Item>
            <ListGroup.Item>SubAdmin: Dapibus ac facilisis in</ListGroup.Item>
            <ListGroup.Item>Project Manager: Morbi leo risus</ListGroup.Item>
            <ListGroup.Item>Specialist: Porta ac consectetur ac</ListGroup.Item>
          </ListGroup>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
