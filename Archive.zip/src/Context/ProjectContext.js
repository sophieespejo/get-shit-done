import { createContext } from "react";

const ProjectContext = createContext(null);

export default ProjectContext;